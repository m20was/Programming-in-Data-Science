library(readxl)
library(dplyr)
library(cowplot)
library(ggplot2)

#Reading the excel file
stu = read_excel("D:/Study/MBA 1st Sem/PDS/R Programming/StudentsPerformance.xlsx")

View(stu)
#Summary of Student Performance Data
summary(stu)

#no. of rows
nrow(stu)

#segregating the groups
grp_count = stu %>% count(group)
grp_count

stu %>% filter(is.na(group))

stu %>% filter(is.na(gender))

stu %>% filter(gender=='male' & group == 'group B')

stu_new = mutate(stu,average_score = round((math_score+reading_score+writing_score)/3))
stu_new$average_score
head(stu_new)

View(stu_new)

#Question 1
#Aggregate Analysis - Groupwise
math_score_aggregate = aggregate(stu_new$math_score, list(stu$group), FUN=mean)
colnames(math_score_aggregate) <- c('group','avg_math_score')
math_score_aggregate

agg_reading_score = aggregate(stu_new$reading_score, list(stu$group), FUN=mean)
colnames(agg_reading_score) <- c('group','avg_reading_score')
agg_reading_score

agg_writing_score = aggregate(stu_new$writing_score, list(stu$group), FUN=mean)
colnames(agg_writing_score) <- c('group','avg_writing_score')
agg_writing_score

agg_average_score = aggregate(stu_new$average_score, list(stu$group), FUN=mean)
colnames(agg_average_score) <- c('group','avg_student_performance')
agg_average_score

dev.off(dev.list()["RStudioGD"]) 

plot1 = ggplot(math_score_aggregate, aes(x=group, y=avg_math_score, fill=group)) + geom_bar(stat="identity") + 
        labs(x="Groups", y="Average_Math_Score")
plot1

plot2 = ggplot(agg_reading_score, aes(x=group, y=avg_reading_score,fill=group)) + geom_bar(stat="identity") + 
  labs(x="Groups", y="Average_Reading_Score")
plot2

plot3 = ggplot(agg_writing_score, aes(x=group, y=avg_writing_score,fill=group)) + geom_bar(stat="identity") + 
  labs(x="Groups", y="Average_Writing_Score")
plot3

plot4 = ggplot(agg_average_score, aes(x=group, y=avg_student_performance,fill=group)) + geom_bar(stat="identity") + 
  labs(x="Groups", y="Average_Student_Performance")
plot4

plot_grid(plot1,plot2,plot3,plot4,labels="AUTO")

#Question 2

grplot2_avg = stu %>% group_by(group,gender) %>%
  summarise(avg_math = mean(math_score))  
grplot2_avg

ggplot(grplot2_avg,(aes(x=group,y=avg_math,fill=gender))) +
  geom_bar(stat = "identity",position = "dodge")


#Question 3

#Adding new column total_mark
total_stu = mutate(stu,total_mark = (math_score+reading_score+writing_score))
total_stu$total_mark
head(total_stu)

#Analysis as per groups
grplot3_total = total_stu %>% group_by(group,gender) %>%
  summarise(sum_total = sum(total_mark))  
grplot3_total

ggplot(grplot3_total,(aes(x=group,y=sum_total,fill=gender))) +
  geom_bar(stat = "identity",position = "dodge")

total_box=ggplot(total_stu, mapping=aes(x=group, y=total_mark, fill=gender))+geom_boxplot()
total_box

