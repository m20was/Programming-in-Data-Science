library(readxl)
library(dplyr)
library(ggplot2)
library(cowplot)

file=read_excel("C:/Users/jithi/Downloads/StudentsPerformance.xlsx")

print (file)

B_table =file %>% filter (group == "group B")

B_table

newfile = mutate(file,average_score = round((math_score+reading_score+writing_score)/3))
newfile$average_score
head(newfile)

#ANS-1

ggplot(B_table,(aes(x=gender,fill=gender))) +
  geom_bar()

math_avg_mks=B_table %>% group_by(gender) %>%
  summarise(math_avg_mks = mean(math_score))

read_avg_mks=B_table %>% group_by(gender) %>%
  summarise(read_avg_mks = mean(reading_score))

writ_avg_mks=B_table %>% group_by(gender) %>%
  summarise(writ_avg_mks = mean(writing_score))

math_avg_mks
read_avg_mks
writ_avg_mks


math_sum_mks=B_table %>% group_by(gender) %>%
  summarise(math_sum_mks = sum(math_score))

read_sum_mks=B_table %>% group_by(gender) %>%
  summarise(read_sum_mks = sum (reading_score))

writ_sum_mks=B_table %>% group_by(gender) %>%
  summarise(writ_sum_mks = sum(writing_score))

aveg_sum_mks=newfile %>% group_by(gender) %>%
  summarise(aveg_sum_mks = sum(average_score))

math_sum_mks
read_sum_mks
writ_sum_mks
aveg_sum_mks

g1 = ggplot(math_sum_mks, aes(x=gender, y=math_sum_mks,fill=gender)) + geom_bar(stat="identity") + 
labs(x="Gender Comparison", y="Math Total")

g2 = ggplot(read_sum_mks, aes(x=gender, y=read_sum_mks,fill=gender)) + geom_bar(stat="identity") + 
  labs(x="Gender Comparison", y="Reading Total")

g3 = ggplot(writ_sum_mks, aes(x=gender, y=writ_sum_mks,fill=gender)) + geom_bar(stat="identity") + 
  labs(x="Gender Comparison", y="Writing Total")

g4 = ggplot(aveg_sum_mks, aes(x=gender, y=aveg_sum_mks,fill=gender)) + geom_bar(stat="identity") + 
  labs(x="Gender Comparison", y="AVerage")

plot_grid(g1,g2,g3,g4,labels="AUTO")

#ANs-2

grp_sum = file %>% group_by(group,gender) %>%
  summarise(sum_math = sum(math_score))  
grp_sum

grp_avg = file %>% group_by(group,gender) %>%
  summarise(avg_math = mean(math_score))  
grp_avg

ggplot(grp_sum,(aes(x=group,y=sum_math,fill=gender))) +
  geom_bar(stat = "identity",position = "dodge")

ggplot(grp_avg,(aes(x=group,y=avg_math,fill=gender))) +
  geom_bar(stat = "identity",position = "dodge")

#ANS-3

total = mutate(file,total_score = (math_score+reading_score+writing_score))
total$total_score
head(total)

grp_total = total %>% group_by(group,gender) %>%
  summarise(sum_total = sum(total_score))  
grp_total

ggplot(grp_total,(aes(x=group,y=sum_total,fill=gender))) +
  geom_bar(stat = "identity",position = "dodge")

total_box=ggplot(total, mapping=aes(x=group, y=total_score))+geom_boxplot()
total_box

total_box=ggplot(total, mapping=aes(x=group, y=total_score, fill=gender))+geom_boxplot()
total_box
